import re
VERSION = '2.0'
def classify_request(text,confidence):
    if not isinstance(text,str) or not text.strip():
        return {'category':'other','action':'input_error'}
    if type(confidence) not in (int,float) or not 0 <= confidence <= 1:
        return {'category':'other','action':'input_error'}
    normalized=text.strip().lower()
    categories={
        'access':['пароль','вход','доступ','учётная запись'],
        'network':['сеть','wi-fi','интернет','сервер недоступен'],
        'equipment':['принтер','ноутбук','компьютер','клавиатура'],
        'software':['программа','приложение','обновление','ошибка установки']}
    matched=[name for name,words in categories.items() if any(re.search(r'\b'+re.escape(word),normalized) for word in words)]
    if len(matched)!=1:
        return {'category':'other','action':'operator_review'}
    return {'category':matched[0],'action':'operator_review' if confidence<.60 else 'auto_route'}
cases=[
('T01','Не могу выполнить вход в учётную запись',.92,('access','auto_route')),
('T02','Нет интернета',.60,('network','auto_route')),
('T03','Принтер и интернет не работают',.90,('other','operator_review')),
('T04','Нужно обновление программы',.55,('software','operator_review')),
('T05','',.80,('other','input_error')),
('T06','Сломалась клавиатура',.86,('equipment','auto_route'))]
passed=0
for ident,text,confidence,expected in cases:
    result=classify_request(text,confidence)
    ok=(result['category'],result['action'])==expected
    passed+=ok
    print(ident,'/'.join(result.values()),'OK' if ok else 'FAIL')
assert passed==6
print('Scenario Pass Rate:',f'{passed/len(cases):.0%}')
print('Арифметический пример:',17,20-17,round(17/20,2))
